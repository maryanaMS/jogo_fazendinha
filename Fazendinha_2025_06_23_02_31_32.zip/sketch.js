let game;

function setup() {
  createCanvas(800, 600);
  textAlign(CENTER, CENTER);
  textSize(32);
  game = new Game();
}

function draw() {
  background(220);
  if (game.estado === 'inicio') {
    game.mostrarTelaInicial();
  } else if (game.estado === 'jogando') {
    game.desenharCena();
    game.mostrarHUD();
  } else if (game.estado === 'viagem') {
    game.mostrarViagem();
  } else if (game.estado === 'fim') {
    game.mostrarTelaFim();
  }
}

function keyPressed() {
  if (keyCode === ENTER) {
    if (game.estado === 'inicio') {
      game.iniciarJogo();
    } else if (game.estado === 'jogando' && game.mostrarProximo) {
      game.proximoNivel();
    } else if (game.estado === 'fim') {
      game.reiniciarJogo();
    }
  }

  if (game.estado === 'jogando') {
    if (keyCode === LEFT_ARROW) game.moverFazendeiro('esquerda');
    if (keyCode === RIGHT_ARROW) game.moverFazendeiro('direita');
    if (keyCode === UP_ARROW) game.moverFazendeiro('cima');
    if (keyCode === DOWN_ARROW) game.moverFazendeiro('baixo');
  }
}

class Game {
  constructor() {
    this.estado = 'inicio';
    this.nivel = 1;
    this.dinheiro = 0;
    this.metaColheita = [5, 10, 15, 20];
    this.plantacoesPorNivel = [
      ['trigo'],
      ['trigo', 'algodao'],
      ['trigo', 'algodao', 'maçã'],
      ['trigo', 'algodao', 'maçã', 'cenoura'],
    ];
    this.emojiPlantas = { trigo: '🌾', algodao: '🧵', maçã: '🍎', cenoura: '🥕' };
    this.fazendeiroEmoji = '👨‍🌾';
    this.fazendeiroPos = createVector(width / 2, height / 2);
    this.plantasAtuais = [];
    this.fazendeiroColhidas = 0;
    this.plantaAtual = null;
    this.mostrarProximo = false;
    this.viagemTempo = 0;
  }

  mostrarTelaInicial() {
    background('#f0e68c');
    fill(0);
    textSize(36);
    text('👨‍🌾  Jogo do Fazendeiro  👨‍🌾', width / 2, 100);
    textSize(20);
    textAlign(LEFT, TOP);
    const linhas = [
      '🎮 Como Jogar:',
      '🠔🠖🠕🠗 Use as setas para mover o fazendeiro',
      '🌾 Colete as plantações encostando nelas',
      '🎯 Alcance a meta do nível para avançar',
      '🚚 Após coletar, o caminhão leva você à cidade',
      '💰 Ganhe dinheiro com cada entrega!',
      '',
      '▶️ Pressione ENTER para começar',
    ];
    for (let i = 0; i < linhas.length; i++) {
      text(linhas[i], width / 2 - 260, 180 + i * 30);
    }
  }

  iniciarJogo() {
    this.estado = 'jogando';
    this.iniciarNivel();
  }

  iniciarNivel() {
    this.fazendeiroPos = createVector(width / 2, height / 2);
    this.plantasAtuais = [];
    this.fazendeiroColhidas = 0;

    // A planta atual será a primeira plantação do nível atual para focar na coleta
    this.plantaAtual = this.plantacoesPorNivel[this.nivel - 1][0];

    this.gerarPlantas();

    this.mostrarProximo = false;
  }

  gerarPlantas() {
    let qtd = this.metaColheita[this.nivel - 1];
    this.plantasAtuais = [];
    for (let i = 0; i < qtd; i++) {
      this.plantasAtuais.push({
        x: random(40, width - 40),
        y: random(120, height - 40),
        coletada: false,
      });
    }
  }

  moverFazendeiro(direcao) {
    const step = 28;
    if (direcao === 'esquerda') this.fazendeiroPos.x -= step;
    if (direcao === 'direita') this.fazendeiroPos.x += step;
    if (direcao === 'cima') this.fazendeiroPos.y -= step;
    if (direcao === 'baixo') this.fazendeiroPos.y += step;

    // limites da tela
    this.fazendeiroPos.x = constrain(this.fazendeiroPos.x, 20, width - 20);
    this.fazendeiroPos.y = constrain(this.fazendeiroPos.y, 120, height - 20);

    this.verificarColisao();
  }

  verificarColisao() {
    for (let p of this.plantasAtuais) {
      if (!p.coletada && dist(this.fazendeiroPos.x, this.fazendeiroPos.y, p.x, p.y) < 30) {
        p.coletada = true;
        this.fazendeiroColhidas++;
        if (this.fazendeiroColhidas >= this.metaColheita[this.nivel - 1]) {
          this.iniciarViagem();
        }
        break;
      }
    }
  }

  iniciarViagem() {
    this.estado = 'viagem';
    this.viagemTempo = millis();
  }

  mostrarViagem() {
    background('#d3d3d3');
    fill('#999');
    noStroke();
    rect(0, height - 80, width, 80);
    textSize(48);
    text('🏠🏢🏪', width / 2, 120);
    text('🚚', width / 2, height - 100);

    // Após 2 segundos, volta ao jogo para próximo nível ou fim
    if (millis() - this.viagemTempo > 2000) {
      this.dinheiro += this.metaColheita[this.nivel - 1] * 10;
      this.estado = 'jogando';

      if (this.nivel < this.metaColheita.length) {
        this.mostrarProximo = true;
      } else {
        this.estado = 'fim';
      }
    }
  }

  proximoNivel() {
    this.nivel++;
    if (this.nivel > this.metaColheita.length) {
      this.estado = 'fim';
    } else {
      // Atualiza plantaAtual para a primeira plantação disponível no nível
      this.plantaAtual = this.plantacoesPorNivel[this.nivel - 1][0];
      this.iniciarNivel();
      this.mostrarProximo = false;
    }
  }

  mostrarTelaFim() {
    background('#222');
    fill(255);
    textSize(36);
    text('🎉 Parabéns! Você completou o jogo! 🎉', width / 2, height / 2 - 40);
    textSize(20);
    text('Pressione ENTER para jogar novamente', width / 2, height / 2 + 40);
  }

  reiniciarJogo() {
    this.estado = 'inicio';
    this.nivel = 1;
    this.dinheiro = 0;
    this.mostrarProximo = false;
  }

  desenharCena() {
    // cenário da fazenda
    background('#a7d948');

    // chão estilizado (linhas)
    stroke('#8b5a2b');
    strokeWeight(3);
    for (let x = 0; x < width; x += 40) {
      line(x, 100, x + 20, 100);
      line(x, height - 20, x + 20, height - 20);
    }

    noStroke();
    textSize(32);
    // desenha as plantas do tipo atual
    for (let p of this.plantasAtuais) {
      if (!p.coletada) {
        text(this.emojiPlantas[this.plantaAtual], p.x, p.y);
      }
    }

    // desenha fazendeiro
    textSize(48);
    text(this.fazendeiroEmoji, this.fazendeiroPos.x, this.fazendeiroPos.y);
  }

  mostrarHUD() {
    fill(0, 150);
    rect(0, 0, width, 100);
    fill(255);
    textAlign(LEFT, TOP);
    textSize(18);

    text(
      `👨‍🌾 Nível: ${this.nivel}\n` +
        `🌱 Planta: ${this.plantaAtual}\n` +
        `📦 Colhidas: ${this.fazendeiroColhidas} / ${this.metaColheita[this.nivel - 1]}\n` +
        `💰 Dinheiro: R$${this.dinheiro}`,
      10,
      10
    );

    if (this.mostrarProximo) {
      fill(0, 200);
      rect(width / 2 - 160, height - 50, 320, 50, 8);
      fill(255);
      textAlign(CENTER, CENTER);
      textSize(18);
      text('Pressione ENTER para o próximo nível', width / 2, height - 25);
    }
  }
}
